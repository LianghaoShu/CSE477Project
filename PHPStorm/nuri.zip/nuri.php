<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <link href="nuri.css" type="text/css" rel="stylesheet" />
    <title>Super Nurikabe</title>
</head>

<body>

<form id="gameform">
<fieldset>
<p>****'s Super Nurikabe</p>

<?php
// This is just some dummy code to create an example of what
// the HTML should look like, though not including any contents
// of the cells other than the numbers.
$values = [
    [0, 0, 0, 4, 0, 0, 0, 7],
    [0, 0, 0, 0, 2, 0, 0, 0],
    [0, 0, 0, 1, 0, 0, 0, 0],
    [0, 0, 4, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 0, 2, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 3, 0, 0, 0, 0, 0],
    [0, 3, 0, 0, 0, 0, 0, 2]
];

$html = '<table>';

for($r=0;  $r<count($values);  $r++) {
    $html .= '<tr>';
    $row = $values[$r];

    for($c=0; $c<count($row);  $c++) {
        $html .= '<td>';
        if($row[$c] !== 0) {
            $html .= $row[$c];
        }

        $html .= '</td>';
    }


    $html .= '</tr>';
}

$html .= '</table>';
echo $html;
?>

<p><input type="submit" name="check" value="Check"></p>
<p><input type="submit" name="giveup" value="Give Up"></p>
<p><input type="submit" name="newgame" value="New Game"></p>
<p><a>Goodbye!</a></p>

</fieldset>
</form>


</body>
</html>
